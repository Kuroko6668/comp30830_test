import setuptools

setuptools.setup(
    name="package1",
    version="5.2.0",
    author="Kuroko",
    author_email="kuroko@qq.com",
    description="",
    long_description="test Module",
    long_description_content_type="text",
    url="http://baidu.com/",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
